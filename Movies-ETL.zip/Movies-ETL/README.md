# Movies-ETL

## Overview: The purpose of this challenge was to extract Wikipedia and Kaggle data from their different files and put them into an SQL database. Regular expressions were used to parse data. The data was cleaned making sure it was consistent and that there was integrity. Once that was made sure of, the data would be then moved from one database to the other. There would then be an ETL function to read the data files and there would then be a clean database loaded into SQL.

